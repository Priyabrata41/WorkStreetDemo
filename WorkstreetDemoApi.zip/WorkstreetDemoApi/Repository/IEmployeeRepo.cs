using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkstreetDemoApi.Models;
using WorkstreetDemoApi.ViewModel;

namespace WorkstreetDemoApi.Repository
{
  public interface IEmployeeRepo
  {
    Task<List<TblEmployee>> GetEmployees();

    Task<int> AddEmployee(TblEmployee employee);
   
    Task<int> DeleteEmployee(string  id);

  }
}

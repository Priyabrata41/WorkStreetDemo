using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WorkstreetDemoApi.Models;
using WorkstreetDemoApi.ViewModel;

namespace WorkstreetDemoApi.Repository
{
  public class EmployeeRepo : IEmployeeRepo
  {
    private readonly EmployeeDbContext _employeeDbContext;
    public EmployeeRepo(EmployeeDbContext employeeDbContext)
    {
      _employeeDbContext = employeeDbContext;
    }
    public async Task<int> AddEmployee(TblEmployee employee)
    {
      if (_employeeDbContext != null)
      {
        await _employeeDbContext.TblEmployees.AddAsync(employee).ConfigureAwait(false);
        await _employeeDbContext.SaveChangesAsync().ConfigureAwait(false);
        return 1;
      }
      return 0;
    }

    public async Task<int> DeleteEmployee(string id)
    {

      var employee = await _employeeDbContext.TblEmployees.FirstOrDefaultAsync(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
      if (_employeeDbContext != null)
      {
        _employeeDbContext.TblEmployees.Remove(employee);
        return await _employeeDbContext.SaveChangesAsync();
      }
      return 0;
    }

    public async Task<List<TblEmployee>> GetEmployees()
    {

      if(_employeeDbContext!=null)
      {
        return await _employeeDbContext.TblEmployees.ToListAsync();
      }
      return null;
    }

   
  }
}

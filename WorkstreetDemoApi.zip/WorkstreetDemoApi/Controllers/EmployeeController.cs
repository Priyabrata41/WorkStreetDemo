using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using WorkstreetDemoApi.Models;
using WorkstreetDemoApi.Repository;
using WorkstreetDemoApi.ViewModel;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WorkstreetDemoApi.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class EmployeeController : ControllerBase
  {
    private IEmployeeRepo _employeeRepo;
    private readonly IMapper _mapper;
    public EmployeeController(IEmployeeRepo employeeRepo, IMapper mapper)
    {
      _employeeRepo = employeeRepo;
      _mapper = mapper;
    }
    // GET: api/<EmployeeController>
    [HttpGet]
    [Route("GetEmployees")]
    public async Task<IActionResult> GetEmployees()
    {
      try
      {
        var employees = await _employeeRepo.GetEmployees().ConfigureAwait(false);
        if (employees.Count == 0)
        {
          return NotFound("No employee found");
        }
        return Ok(employees);
      }
      catch(Exception ex)
      {
        return BadRequest();
      }
    }



    // POST api/<EmployeeController>
    [HttpPost]
    [Route("AddEmployee")]
    public async Task<IActionResult> Post([FromBody] EmployeeViewModel employee)
    {
      if (!ModelState.IsValid)
        return BadRequest();

      try
      {
        var result = 0;
        var employeeMapped = _mapper.Map<TblEmployee>(employee);
        var empAdded = await _employeeRepo.AddEmployee(employeeMapped).ConfigureAwait(false);
        if (empAdded == 0)
        {
          return BadRequest("Could not add employee");
        }
        else
        {
          return Ok("Employee added");
        }
      }
      catch(Exception ex)
      {
        return BadRequest();
      }
    }

    // PUT api/<EmployeeController>/5
    [HttpPut("{id}")]
    public void Put(int id, [FromBody] string value)
    {
    }

    // DELETE api/<EmployeeController>/5
    [HttpPost]
    [Route("DeletePost")]
    public async Task<IActionResult> Delete(string id)
    {
      int result = 0;

      if(id == null)
      {
        return BadRequest("Please provide a valid employee id");
      }
      try{
        result = await _employeeRepo.DeleteEmployee(id);
        if (result == 0)
        {
          return BadRequest("Could not delete employee");
        }
        else
        {
          return Ok("Employee deleted");
        }
      }
      catch
      {
        return BadRequest();
      }
    }
  }
}

using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkstreetDemoApi.Models;
using WorkstreetDemoApi.ViewModel;

namespace WorkstreetDemoApi.Mapper
{
  public class EmployeeMapper: Profile
  {
    public EmployeeMapper()
    {
      CreateMap<TblEmployee, EmployeeViewModel>();
      CreateMap<EmployeeViewModel, TblEmployee>();
    }
  }
}
